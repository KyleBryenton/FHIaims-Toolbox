#!/bin/bash

##########
 # For most jobs with <20 atoms, you want:
 # - 1 core per task
 # - Memory should be set to 5-10% larger than largest job will require. Remember FHIaims has 0.5-1.0 GB of overhead that isn't reported.
 # - 24hr walltime per meta job, resubmitting once a day until all jobs are done
 # - 100 meta jobs should be submitted. More than this and the job scheduler struggles to start them
 # For large amounts of large tasks, consider reserving whole-nodes instead. Ask your PI.
 #
 # Frequently used commands:
 # - submit.run N   	- Submit the farm to the scheduler.  Submits as `N` farms.
 # - resubmit.run N 	- Resubmit all computations which failed or never ran as a new farm. Submits as `N` farms.
 # - query.run		- Displays a short summary of the farm. WARNING: Only says if submission was successful, not if job was successful.
 # - list.run		- List all the jobs with their current state for the farm.
 # - kill.run		- List all the jobs with their current state for the farm.
 # - clean.run		- Deletes almost all files. WARNING: Also deletes your job directories!!
 # 
 # Additional Resources:
 # https://docs.alliancecan.ca/wiki/META:_A_package_for_job_farming
 # https://docs.alliancecan.ca/wiki/META:_Advanced_features_and_troubleshooting
 # https://www.youtube.com/watch?v=GcYbaPClwGE
 #
 #
 # To create your table.dat, go to the top-most META directory and run:
 #     find . -type f -name "control.in" | cut -c 3- | rev | cut -c 12- | rev | sort | nl -nln >> table.dat
 #
 # Explanation:
 # - `find . -type f - name "control.in"` will find all `f` (files) from the `.` (current) directory and below that are named "control.in"
 # - `| cut -c 3- |` will remove the "./" from the start of each entry.
 # - `| rev | cut -c 12- | rev` will remove the "/control.in" from the end of each entry
 # - `sort` will sort it so it appears in the same order you see in your directory structure
 # - `nl -nln` will number each line
 # - `>> table.dat` will write the file
 #
 # To run only a subdirectory, e.g. ./H2/FARM_2, instead run:
 #     find ./H2/FARM_2 -type f -name "control.in" | cut -c 3- | rev | cut -c 12- | rev | sort | nl -nln >> table.dat
 #
 # The accompanying single_case.sh should have a line that says "if ! grep -sq "Have a nice day." *.out"
 # If it does, you can see any FHIaims jobs that crashed by entering OUTPUT/, and running
 # 	grep "Bad day" *
 #
 # Common Presets:
 #
 # --nodes=1
 # --ntasks-per-node=32
 # --mem-per-cpu=4000M
 # --time=24:00:00
 # --account=rrg-ejohnson
 #
 # --nodes=1
 # --tasks-per-node=64
 # --mem=0
 # --time=24:00:00
 # --account=rrg-ejohnson
##########

#SBATCH --nodes=1
#SBATCH --ntasks-per-node=16
#SBATCH --mem-per-cpu=4000M
#SBATCH --time=24:00:00
#SBATCH --account=def-ejohnson
module purge
module load StdEnv/2023
module load intel/2023.2.1 intelmpi/2021.9.0 imkl/2023.2.0 libxc/6.2.2
module load meta-farm
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export MKL_DYNAMIC=FALSE
ulimit -s unlimited
# Don't change this line:
task.run
date
