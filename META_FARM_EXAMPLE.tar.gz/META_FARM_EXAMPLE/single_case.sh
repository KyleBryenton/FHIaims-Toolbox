#!/bin/bash
# The actual (serial) computation, for a single case No. $2 in the table $1.

TABLE1=$1
i1=$2

# Total number of cases:
## If the env. variable N_cases is defined, using it, otherwise computing the number of lines in the table:
if test -z $N_cases
  then
  N_cases=`cat "$TABLE1" | wc -l`
  fi

# Exiting if $i1 goes beyond $N_cases (can happen in bundled farms):
if test $i1 -lt 1 -o $i1 -gt $N_cases  
  then
  exit
  fi
  
# Extracing the $i1-th line from file $TABLE1:
LINE=`sed -n ${i1}p $TABLE1`
# Case id (from the original cases table):
ID=`echo "$LINE" | cut -d" " -f1`
# The rest of the line:
COMM=`echo "$LINE" | cut -d" " -f2-`

METAJOB_ID=${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}

# ++++++++++++++++++++++  This part can be customized:  ++++++++++++++++++++++++
#  Here:
#  $ID contains the case id from the original table (can be used to provide a unique seed to the code etc)
#  $COMM is the line corresponding to the case $ID in the original table, without the ID field
#  $METAJOB_ID is the jobid for the current meta-job (convenient for creating per-job files)

# Using 'pushd' to easily return via 'popd'
pushd $COMM > /dev/null
echo -e "\n\n"
echo "Case $ID: $COMM"
date

# Link your FHIaims build/aims.######.mpi.x here:
FHIAIMS=~/projects/def-ejohnson/FHIaims/B86bPBE0_XDMrv3_Stable/build/aims.230214.scalapack.mpi.x

# Outputting to the same name as the containing directory (useful for benchmark eval).
mpirun $FHIAIMS < /dev/null > ${COMM##*/}.out

# Exit status of the code, used for resubmit.run
STATUS=$?
if [ $STATUS -eq 0 ] ; then
  if ! grep -sq "Have a nice day." *.out ; then 
    STATUS=1
    echo "Bad day in $ID: $COMM"
  fi
else 
  if grep -sq "Have a nice day." *.out ; then
    STATUS=0
    echo "Unclean termination but nice day in $ID: $COMM"
  fi
fi

# Using 'popd' to return to the last directory 'pushd' was used
popd > /dev/null

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# Saving all current metajob statuses to a single file with a unique name:
echo $ID $STATUS >> STATUSES/status.$METAJOB_ID
