#!/bin/bash
#SBATCH -t 0-00:30
#SBATCH --mem=4G
#  You have to replace Your_account_name below with the name of your account:
#SBATCH -A Your_account_name

# Don't change anything below this line

autojob.run
